import { Component } from '@angular/core';
import { SampleReducer } from './store/sample.reduces';
import { Store } from '@ngrx/store';
import { Observable } from 'rxjs';
//import { Action } from 'rxjs/internal/scheduler/Action';
import { VotingModel } from './store/voting.model';
import * as VotingAction from './store/voting.action';

interface appState{
  message : string
  voting : VotingModel
}


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})
export class AppComponent {
  title = 'course-project';
  message$ : Observable<string>;
  voting$ : Observable<VotingModel>;
  text ='';
  constructor(private store: Store<appState>){
    this.message$ = this.store.select('message');
    this.voting$ =this.store.select('voting');
  }
  onBengali(){
    this.store.dispatch({type : 'BENGALI'});

  }
   
  onHindi(){
    this.store.dispatch({type : 'HINDI'});
    
  }
  onChange(){
    this.store.dispatch(new VotingAction.editText(this.text));
  }
  onDownvote(){
    this.store.dispatch(new VotingAction.downvote());

  }
  onUpvote(){
    this.store.dispatch(new VotingAction.upvote());
  }
  onReset(){
    this.store.dispatch(new VotingAction.reset())
  }
  

}
