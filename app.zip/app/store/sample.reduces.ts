// const stateApp{
//     message : 'Hi How are you?'
// }

export function SampleReducer(state = "stateApp", action){
    console.log(action);
    switch(action.type){
        case 'BENGALI' :
            state='Hi kemon Acho?';
            return state;
        case 'HINDI' :
            state='Hi Kaise ho?'
            return state;
        default :
            return state;
        }
}