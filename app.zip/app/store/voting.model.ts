export interface VotingModel{
    text : string,
    likes : number
}