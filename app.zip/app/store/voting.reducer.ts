import { Action } from '@ngrx/store';
import { VotingModel } from './voting.model';
import * as VotingAction from './voting.action';
const initialState : VotingModel ={
    text : 'default title',
    likes : 0
}
export const newState= (state, newData) =>{
    return Object.assign({},state,newData);
}
export function votingReducer(state : VotingModel=initialState, action : VotingAction.all){
    console.log(state, action);
    switch(action.type){
        case VotingAction.EDIT_TEXT:
            return newState(state,{ text : action.payload});
        case VotingAction.UPVOTE:
            return newState(state,{ likes : state.likes+1});
        case VotingAction.DOWNVOTE:
            return newState(state, { likes : state.likes -1});
        case VotingAction.RESET:
            return initialState;
        default:
            return state;
    }
}