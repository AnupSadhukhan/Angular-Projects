import { Action} from '@ngrx/store';


export const EDIT_TEXT="EDIT_TEXT";
export const UPVOTE="UPVOTE";
export const DOWNVOTE="DOWNVOTE";
export const RESET="RESET";

export class editText implements Action{
    readonly type=EDIT_TEXT;
    constructor(public payload : string){}
}
export class upvote implements Action{
    readonly type=UPVOTE;
}
export class downvote implements Action{
    readonly type=DOWNVOTE;

}
export class reset implements Action{
    readonly type=RESET;
}

export type all= editText | upvote | downvote | reset;