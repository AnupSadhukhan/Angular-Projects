import { Injectable } from '@angular/core';
import {userModel } from '../model/user.model';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  users : userModel[]=[];
  constructor() { }
  
  createUser(user : userModel){
    this.users.push(user);
    console.log(user)
    return this.users.slice();
  }
  getUsers(){
   return this.users.slice();
  }
  updateUser(index : number,user: userModel){
    this.users[index]=user;
    console.log(user);
     return this.users.slice();
  }
  deleteUser(index){
    this.users.splice(index,1);
    
  }
}
