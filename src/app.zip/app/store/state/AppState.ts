// import { UserState,initialUserState } from '../reducers/user.reducer';

// export interface AppStateInterface{
//     userState : UserState;
// }
// export const AppState{
//     userState : initialUserState
// }