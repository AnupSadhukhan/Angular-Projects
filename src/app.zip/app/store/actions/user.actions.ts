import {Action} from '@ngrx/store';



export const enum UserActions{
    USER_ADD='[USER] USER ADD',
    USER_ADD_SUCCESS='[USER] USER ADD SUCCESS',
    USER_ADD_FAIL='[USER] USER ADD FAIL',

}
//export const USER_ADD='[USER] USER ADD';


export class UserAdd implements Action{
    readonly type=UserActions.USER_ADD;
}
export class UserAddSuccess implements Action{
    readonly type=UserActions.USER_ADD_SUCCESS;
    constructor(private payload){}
}
export class UserAddFail implements Action{
    readonly type = UserActions.USER_ADD_FAIL;
    
}

export type allUserActions= UserAdd | UserAddSuccess | UserAddFail;
