export interface userModel{
    id : number;
    fullName : string;
    age : number;
    company : string;
}